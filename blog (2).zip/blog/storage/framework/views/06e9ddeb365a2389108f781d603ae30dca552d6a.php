<?php $__env->startSection('body'); ?>

    <?php $__currentLoopData = $allCrops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allCrop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 product-men">
            <div class="men-pro-item simpleCart_shelfItem">
                <div class="men-thumb-item">
                    <img  src="<?php echo e(asset($allCrop->product_image)); ?> " width="1000" height="400" >
                    <span class="product-new-top"></span>
                </div>
                <div class="item-info-product ">
                    <h4 class="text-success"><?php echo e($allCrop->product_name); ?></h4>
                    <div class="info-product-price">
                        <span class="item_price"><?php echo e($allCrop->product_quantity); ?></span>
                    </div>
                </div>
                <div>
                    <a href="<?php echo e(route('farmer_home_details',['id'=>$allCrop->id])); ?>" class="col-md-offset-5 item_add single-item hvr-outline-out">Details</a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('farmer.headerFooter', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>