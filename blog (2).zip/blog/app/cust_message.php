<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cust_message extends Model
{
    //
    protected $fillable =['crop_id','product_name','farmer_email','message'];
}
