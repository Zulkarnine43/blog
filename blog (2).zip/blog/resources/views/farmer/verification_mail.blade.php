<p>I would be appriviative , if  gone through this feedback... </p>
<a href="{{route('registerVerify')}}">For verify Click Here</a>
