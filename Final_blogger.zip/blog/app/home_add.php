<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class home_add extends Model
{
    //
    protected $fillable=['product_name','crop_type','product_quantity','product_price','product_description','long_description','product_image'];
}
