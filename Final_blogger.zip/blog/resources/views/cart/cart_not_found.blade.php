@extends('home.headerFooter')
@section('body')
    <h1>Not have any order</h1>
    @endsection
