<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <h3 class="text-success text-success"></h3>
                    <h3 class="col-md-offset-3 col-md-5 text-center font-italic" style="background-color: darkgray; color: black;"> Register</h3>
                    <h1><?php echo e(Session::get('verify')); ?></h1>

                    <form action="<?php echo e(route('registerSave')); ?>" method="POST" >
                        <?php echo csrf_field(); ?>
                        <div class="form-group col-md-offset-4 col-md-4">
                            <label>fullname</label>
                            <input type="text" class="form-control"  type="text" value="" name="fullname" placeholder="fullname">
                            <span class="text-danger"><?php echo e($errors->has('fullname') ? $errors->first('fullname'): ' '); ?></span>
                        </div>

                        <div class="form-group col-md-offset-4 col-md-4">
                            <label>username</label>
                            <input type="text" class="form-control"  type="text" value="" name="username" placeholder="username">
                            <span class="text-danger"><?php echo e($errors->has('username') ? $errors->first('username') : ' '); ?></span>
                        </div>


                        <div class="form-group col-md-offset-4 col-md-4">
                            <label>email</label>
                            <input type="text" class="form-control"  type="text" value="" name="email" placeholder="email">
                            <span class="text-danger"><?php echo e($errors->has('email') ? $errors->first('email') : ' '); ?></span>
                        </div>


                        <div class="form-group col-md-offset-4 col-md-4">
                            <label>mobile</label>
                            <input type="number" class="form-control"  type="number" value="" name="mobile" placeholder="mobile">
                            <span class="text-danger"><?php echo e($errors->has('mobile') ? $errors->first('mobile') : ' '); ?></span>
                        </div>

                        <div class="form-group col-md-offset-4 col-md-4">
                            <label>Select Your Division</label>
                            <select class="col-md-offset-0 col-md-12 text-center" name="district" >
                                <option value="null"><-------Select Your Division------------></option>
                                <option value="Dhaka">Dhaka</option>
                                <option value="Rajshahi">Rajshahi</option>
                                <option value="Khulna">Khulna</option>
                                <option value="Chittagong">Chittagong</option>
                                <option value="Barishal">Barishal</option>
                                <option value="Comilla">Comilla</option>
                                <option value="Rangpur">Rangpur</option>
                            </select>
                        </div>


                        <div class="form-group col-md-offset-4 col-md-4">
                            <label>postal_code</label>
                            <input type="number" class="form-control"  type="number" value="" name="postal_code" placeholder="postal_code">
                            <span class="text-danger"><?php echo e($errors->has('postal_code') ? $errors->first('postal_code') : ' '); ?></span>
                        </div>

                        <div class="form-group col-md-offset-4 col-md-4">
                            <label>Password</label>
                            <input type="password" class="form-control"  type="password" value="" name="password" placeholder="Password">
                            <span class="text-danger"><?php echo e($errors->has('password') ? $errors->first('password') : ' '); ?></span>
                        </div>

                        <div class="form-group col-md-offset-4 col-md-4">
                            <label>confirm_password</label>
                            <input type="password" class="form-control"  type="password" value="" name="confirm_password" placeholder="confirm_password">
                            <span class="text-danger"><?php echo e($errors->has('confirm_password') ? $errors->first('confirm_password') : ' '); ?></span>
                        </div>

                        <input class="col-md-offset-4 col-md-2 text-center text-black-50 btn-success" type="submit" name="btn" value="Submit">
                    </form>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.headerFooter', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>